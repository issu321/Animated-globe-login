
<?php
$host="localhost";
$user="root";
$password="";
$db="login_system";

$conn = new mysqli($host,$user,$password);

$conn->query("CREATE DATABASE IF NOT EXISTS $db");
$conn->select_db($db);

$conn->query("CREATE TABLE IF NOT EXISTS users(
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(50),
password VARCHAR(255)
)");

$check=$conn->query("SELECT * FROM users WHERE username='admin'");

if($check->num_rows==0){
$conn->query("INSERT INTO users(username,password) VALUES('admin',MD5('1234'))");
}
?>
