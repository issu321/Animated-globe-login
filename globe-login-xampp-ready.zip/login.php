
<?php
session_start();
require_once "db.php";

$username = $_POST['username'];
$password = md5($_POST['password']);

$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);

if($result && $result->num_rows > 0){
$_SESSION['user']=$username;
header("Location: dashboard.php");
}else{
echo "<h2 style='color:red;text-align:center'>Invalid Login</h2><a href='index.php'>Back</a>";
}
?>
