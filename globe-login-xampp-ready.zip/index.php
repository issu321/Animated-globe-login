
<?php
// Auto setup if DB not ready
require_once "setup.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Globe Login</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial, Helvetica, sans-serif;}
body{
height:100vh;background:black;overflow:hidden;
display:flex;align-items:center;justify-content:center;color:white;
}
.stars{
position:absolute;width:100%;height:100%;
background:url("https://www.transparenttextures.com/patterns/stardust.png");
animation:moveStars 200s linear infinite;
}
@keyframes moveStars{
from{background-position:0 0;}
to{background-position:10000px 5000px;}
}
.globe{
position:absolute;width:500px;height:500px;border-radius:50%;
background:
radial-gradient(circle at 30% 30%, #00e5ff, transparent 40%),
radial-gradient(circle at 70% 70%, #8a2be2, transparent 40%),
radial-gradient(circle, #0a0a0a 40%, #000 60%);
box-shadow:0 0 60px #00e5ff,0 0 120px #8a2be2,inset 0 0 50px #000;
animation:rotateGlobe 20s linear infinite;
}
@keyframes rotateGlobe{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
.login-box{
position:relative;z-index:10;width:350px;padding:40px;border-radius:15px;
background:rgba(255,255,255,0.05);backdrop-filter:blur(15px);
border:1px solid rgba(255,255,255,0.2);
}
input{
width:100%;padding:12px;margin-bottom:15px;border:none;border-radius:8px;
background:rgba(255,255,255,0.1);color:white;
}
button{
width:100%;padding:12px;border:none;border-radius:8px;
background:linear-gradient(45deg,#00e5ff,#8a2be2);color:white;cursor:pointer;
}
</style>
</head>

<body>

<div class="stars"></div>
<div class="globe"></div>

<div class="login-box">
<h2>Login</h2>

<form action="login.php" method="POST">
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Sign In</button>
</form>

<p style="margin-top:10px;font-size:13px;color:#aaa">
Default login → admin / 1234
</p>

</div>

</body>
</html>
