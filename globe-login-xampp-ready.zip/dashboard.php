
<?php
session_start();
if(!isset($_SESSION['user'])){
header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
</head>
<body style="background:black;color:white;text-align:center;margin-top:200px;">

<h1>Welcome <?php echo $_SESSION['user']; ?></h1>
<p>You logged in successfully.</p>

<a href="logout.php" style="color:cyan">Logout</a>

</body>
</html>
