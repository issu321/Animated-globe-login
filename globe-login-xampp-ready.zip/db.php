
<?php
$host="localhost";
$user="root";
$password="";
$db="login_system";

$conn = new mysqli($host,$user,$password,$db);

if($conn->connect_error){
die("Database not ready.");
}
?>
